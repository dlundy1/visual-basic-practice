﻿Partial Class ContactsDataSet
End Class

Namespace ContactsDataSetTableAdapters
    Partial Public Class PublishersTableAdapter
    End Class
End Namespace
